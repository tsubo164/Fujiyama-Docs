#Copyright (c) 2011-2014 Hiroshi Tsubokawa
#See LICENSE.txt and README.txt

Fujiyama Renderer for Windows 64bit
===================================

Install
    Copy Fujiyama-Renderer to C:\Fujiyama-Renderer
    set PATH=%PATH%;C\Fujiyama-Renderer\bin
    set PYTHONPATH=%PYTHONPATH%;C\Fujiyama-Renderer\python

Convert
    ply2mesh.exe teapot.ply  teapot.mesh
    obj2mesh.exe head.obj    head.mesh
    hdr2mip.exe  pisa.hdr    pisa.mip
    jpg2mip.exe  rock.jpg    rock.mip

Render
    scene.exe    teapot.scn
    type teapot.scn | scene.exe
    python       bump_mapping.py
