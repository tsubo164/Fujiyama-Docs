Fujiyama Renderer
=================

Render sample scene
-------------------

To render the sample cube scene, go to bin folder and
double-click render_sample.cmd in this folder.

This actually executes cube.exe that creates the scene
and render it using C APIs.

The other scene files written in scene scripts
are in scenes folder.
